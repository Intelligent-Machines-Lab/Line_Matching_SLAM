#!/usr/bin/env python

# This code publishes a Float32 topic on ROS called 'yaw'
# The information is the yaw angle from the witmotion IMU connected through serial comm
# Angle in degrees

import serial
import time
import struct

import rospy
from std_msgs.msg import Float32

att = 180 / 32768.0

#yaw = 0.0

def pub_yaw():
 #   global yaw
    pub = rospy.Publisher('yaw', Float32, queue_size=10)
    rospy.init_node('pub_yaw', anonymous=True)
    rate = rospy.Rate(50) # 10hz
    while not rospy.is_shutdown():
	#print('ok')
        yaw = get_imu_serial(0) # 1 for debug, 0 for nothing
	#print(yaw)
        msg = float(yaw)

        #rospy.loginfo(msg)
        pub.publish(msg)
        rate.sleep()
        #rospy.spin()

def get_imu_serial(debug=0):
  #  global yaw
    data = port.read(11)
   #print(data)
   #print('ok2')
    if data[1] == b'\x53':
        axes = struct.unpack("<hhh", data[2:8])
        x3, y3, z3 = [a*att for a in axes]
        #print('Attitude - x:'+str(x3)+', y:'+str(y3)+', z:'+str(z3))
        if debug:
            print(str(z3))
        yaw = float(z3)
        return yaw

if __name__ == '__main__':
    # Serial stuff
    port = serial.Serial("/dev/ttyAMA0", baudrate=115200, timeout=10.0)
    try:
        pub_yaw()
    except rospy.ROSInterruptException:
        print('Serial port closed due to ROSInterruptException')
        port.close()
