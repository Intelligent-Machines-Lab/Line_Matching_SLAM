import freenect
import cv2
import numpy as np
from tag_detection import detect_aruco_camera

#function to get RGB image from kinect
def get_video():
    array,_ = freenect.sync_get_video()
    array = cv2.cvtColor(array,cv2.COLOR_RGB2GRAY)
    return array

#function to get depth image from kinect
def get_depth():
    array,_ = freenect.sync_get_depth()
    array = array.astype(np.uint8)
    return array

# Tag Detection
tag_size = 0.1821
T = np.eye(4)


for i in range(10):
    gray = get_video()
    print('passed')
    fx = 594.21
    fy = 591.04
    cx = 339.5
    cy = 242.7
    #cameraParams = [fx, fy, cx, cy]
    cameraParams = np.matrix([[fx, 0, cx], [0, fy, cy], [0, 0, 1]])
    iSeeYou = False
    print(i)
    try:
        iSeeYou, rel, ID, c = detect_aruco_camera(gray, tag_size, T, cameraParams)
    except Exception as e:
        iSeeYou = False
        print(e)

    if iSeeYou:
        print(rel)
    else:
        print('Not detected')
