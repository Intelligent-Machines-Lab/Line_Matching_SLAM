#!/usr/bin/env python
import roslib
roslib.load_manifest('isis')
import rospy
from std_msgs.msg import Float64MultiArray

import freenect
import cv2
import numpy as np
from tag_detection import detect_aruco_camera

#function to get RGB image from kinect
def get_video():
    array,_ = freenect.sync_get_video()
    array = cv2.cvtColor(array,cv2.COLOR_RGB2GRAY)
    #freenect.sync_stop()
    return array

#function to get depth image from kinect
def get_depth():
    array,_ = freenect.sync_get_depth()
    array = array.astype(np.uint8)
    return array

if __name__ == "__main__":
    rospy.init_node('rel_info_pub')

    rate = rospy.Rate(5.0)

    pub = rospy.Publisher('rel_info_isis', Float64MultiArray, queue_size=10)
    # Tag Detection
    tag_size = 0.1821
    T = np.eye(4)
    fx = 594.21
    fy = 591.04
    cx = 339.5
    cy = 242.7
    #cameraParams = [fx, fy, cx, cy]
    cameraParams = np.matrix([[fx, 0, cx], [0, fy, cy], [0, 0, 1]])
    while not rospy.is_shutdown():
        print('Before get_video')
        gray = get_video()
        print('Passed get_video')
        iSeeYou = False

        try:
            #gray = get_video()
            iSeeYou, rel, ID, c = detect_aruco_camera(gray, tag_size, T, cameraParams)
        except Exception as e:
            iSeeYou = False
            print('In exception routine...')
            print(e)

        if iSeeYou:
            r_rgb = rel[0]
            theta_rel_rgb = rel[1]
            rel_final = [r_rgb, theta_rel_rgb]
            #print(rel)
        else:
            rel_final = []
            #print('\nNot detected')
        data_to_send_2 = Float64MultiArray(data=rel_final)
        pub.publish(data_to_send_2)
        rate.sleep()
