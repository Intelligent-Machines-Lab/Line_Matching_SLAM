#from pupil_apriltags import Detector
import cv2
from cv2 import aruco
from matplotlib import pyplot as plt
import numpy as np
#import apriltag


def detect_aruco_camera(img, tagSize, T_off, cameraParams):
	aruco_dict = aruco.Dictionary_get(aruco.DICT_6X6_250)
	parameters =  aruco.DetectorParameters_create()
	cameraMatrix = cameraParams
	distCoeffs = None
	debug_viz = False
	T_cam = np.array([0, 0, 1, 0, -1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1]).reshape(4,4)

	corners, ids, rejectedImgPoints = aruco.detectMarkers(img, aruco_dict, parameters=parameters)
	
	if ids is None:
		iSeeYou = False
		ID = []
		rel = []
		c = []

	else:
		ret = aruco.estimatePoseSingleMarkers(corners, tagSize, cameraMatrix, distCoeffs)
		(rvec, tvec) = (ret[0][0, 0, :], ret[1][0, 0, :])

		p = np.array(tvec).reshape((3, 1))
		po = np.concatenate((p, np.array([[1]])), axis=0)
		pos_cam = np.matmul(T_cam, po)
		pos_robot = np.matmul(T_off, pos_cam)
		# Get in polar
		r_aux, th_aux = cart2pol(pos_robot[0], pos_robot[1])
		print('found a tag!!!')
		print((r_aux, th_aux))
		iSeeYou = True
		rel = (r_aux, th_aux)
		ID = ids[0]
		corner = corners[0][0]
		c = np.mean(corner, axis=0)

		if debug_viz:
			# Viz debug (remove in later versions)
			fig, (ax1, ax2) = plt.subplots(1, 2)
			fig.suptitle('Multi Tag detection')
			ax1.imshow(img, cmap = 'gray', interpolation = 'bicubic')
			ax1.plot(corner[:, 0], corner[:, 1], 'r', linewidth=3)
			ax2.plot([0, pos_robot[0]], [0, pos_robot[1]], 'ro-')
			txt = 'r = ' + str(r_aux) + '\nth = ' + str(np.rad2deg(th_aux)) + '\nc = ' + str(c)
			ax2.text(pos_robot[0], pos_robot[1], txt)
			ax2.grid(True)
			ax2.axis('equal')
			plt.show()

	return iSeeYou, rel, ID, c
'''
def detect_tag_camera_2(img, tagSize, T_off, cameraParams):
	# Creates a detector containing the family of tags and quality params
	options = apriltag.DetectorOptions(families='tag36h11', border=1, nthreads=4, quad_decimate=1.0, quad_blur=0.0, refine_edges=True, refine_decode=False, refine_pose=False, debug=False, quad_contours=True)
	at_detector = apriltag.Detector(options)
	# Detect tag pose using apriltags
	tags = at_detector.detect(img)

	

	
	debug_viz = False
	if tags:

		if debug_viz:
			# Viz debug (remove in later versions)
			fig, (ax1, ax2) = plt.subplots(1, 2)
			fig.suptitle('Multi Tag detection')
			ax1.imshow(img, cmap = 'gray', interpolation = 'bicubic')

		# Transformation of tag pose frame to robot frame
		T_cam = np.array([0, 0, 1, 0, -1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1]).reshape(4,4)
		
		centroid = []
		r = []
		theta_rel = []
		best_belief = 0
		# For each detection in tags
		for tag in tags:
			pose, e0, e1 = at_detector.detection_pose(tag, cameraParams, tagSize)

			# Extract information from detection
			p = np.array(pose[:3, 3]).reshape((3, 1))
			tID = tag.tag_id
			corner = tag.corners
			belief = tag.decision_margin
			c = tag.center
			
			# Transforming pose
			po = np.concatenate((p, np.array([[1]])), axis=0)
			pos_cam = np.matmul(T_cam, po)
			pos_robot = np.matmul(T_off, pos_cam)
			# Get in polar
			r_aux, th_aux = cart2pol(pos_robot[0], pos_robot[1])
			
			txt = 'r = ' + str(r_aux) + '\nth = ' + str(np.rad2deg(th_aux)) + '\nc = ' + str(c)
			print(txt)
			if belief > best_belief:
				# Update final answer
				best_belief = belief
				r = r_aux
				theta_rel = th_aux
				tagID = tID
				centroid = c


			if debug_viz:
				ax1.plot(corner[:, 0], corner[:, 1], 'r', linewidth=3)
				ax2.plot([0, pos_robot[0]], [0, pos_robot[1]], 'ro-')
				ax2.text(pos_robot[0], pos_robot[1], txt)
		if debug_viz:
			ax2.grid(True)
			ax2.axis('equal')
			plt.show()

		iSeeYou = True
		ID = tagID
		rel = [r, theta_rel]
		c = centroid
	else:
		iSeeYou = False
		ID = []
		rel = []
		c = []

	return iSeeYou, rel, ID, c
'''
# Detects relative information from april tags in images given camera params and tag size
# inputs: img = RGB image as a matrix
#         tagSize = scalar, side length of tag in meters
#         T_off = offset transformation in angle and position as an homogeneous matrix 4x4
#         cameraParams = list of camera params in the format [fx, fy, cx, cy]
# output: iSeeYou = boolean stating if detection was successful
#         rel = list of relative information as [r, theta_rel] r is the distance in meters and theta_rel the angle in radians
#         ID = id of detected tag
#         c = centroid of tag
'''
def detect_tag_camera(img, tagSize, T_off, cameraParams):
	# Creates a detector containing the family of tags and quality params
	at_detector = Detector(families='tag36h11', nthreads=1, quad_decimate=1.0, quad_sigma=0.0, refine_edges=1, decode_sharpening=0.25, debug=0)

	try:
		# Detect tag pose using pupil_apriltags
		tags = at_detector.detect(img, estimate_tag_pose=True, camera_params=cameraParams, tag_size=tagSize)
	except Exception as e:
		print(e)

	debug_viz = False
	if tags:
		if debug_viz:
			# Viz debug (remove in later versions)
			fig, (ax1, ax2) = plt.subplots(1, 2)
			fig.suptitle('Multi Tag detection')
			ax1.imshow(img, cmap = 'gray', interpolation = 'bicubic')

		# Transformation of tag pose frame to robot frame
		T_cam = np.array([0, 0, 1, 0, -1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1]).reshape(4,4)
		
		centroid = []
		r = []
		theta_rel = []
		best_belief = 0
		# For each detection in tags
		for i in range(len(tags)):
			p = tags[i].pose_t
			tID = tags[i].tag_id
			corner = tags[i].corners
			belief = tags[i].decision_margin
			c = tags[i].center
			
			# Transforming pose
			p = np.array(p)
			po = np.concatenate((p, np.array([[1]])), axis=0)
			pos_cam = np.matmul(T_cam, po)
			pos_robot = np.matmul(T_off, pos_cam)
			# Get in polar
			r_aux, th_aux = cart2pol(pos_robot[0], pos_robot[1])
			
			txt = 'r = ' + str(r_aux) + '\nth = ' + str(np.rad2deg(th_aux)) + '\nc = ' + str(c)
			print(txt)
			if belief > best_belief:
				# Update final answer
				best_belief = belief
				r = r_aux
				theta_rel = th_aux
				tagID = tID
				centroid = c


			if debug_viz:
				ax1.plot(corner[:, 0], corner[:, 1], 'r', linewidth=3)
				ax2.plot([0, pos_robot[0]], [0, pos_robot[1]], 'ro-')
				ax2.text(pos_robot[0], pos_robot[1], txt)
		if debug_viz:
			ax2.grid(True)
			ax2.axis('equal')
			plt.show()

		iSeeYou = True
		ID = tagID
		rel = [r, theta_rel]
		c = centroid
	else:
		iSeeYou = False
		ID = []
		rel = []
		c = []

	return iSeeYou, rel, ID, c
'''
def cart2pol(x, y):
	rho = np.sqrt(x**2 + y**2)
	phi = np.arctan2(y, x)
	return(rho, phi)

"""
def main():
	#K = [336.7755634193813, 0.0, 333.3575643300718, 0.0, 336.02729840829176, 212.77376312080065, 0.0, 0.0, 1.0]
	K = [611.450989, 0.0, 433.203979, 0.0, 611.485718, 249.473022, 0.0, 0.0, 1.0]
	
	#tag_size = 0.065
	tag_size = 0.113
	
	fx = K[0]
	fy = K[4]
	cx = K[2]
	cy = K[5]
	cameraParams = [fx, fy, cx, cy]

	img = cv2.imread('tag1_cut.png',cv2.IMREAD_GRAYSCALE)
	#img = cv2.imread('test_image.png',cv2.IMREAD_GRAYSCALE)

	'''
	T_off = np.eye(4)
	iSeeYou, rel, ID, c = detect_tag_camera(img, tag_size, T_off, cameraParams)
	row, col = np.floor(c)
	print((row, col))
	
	T_off_1 = np.eye(4)
	T_off_2 = np.array([[0.0, -1.0, 0.0, 0.0], [1.0, 0.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0], [0.0, 0.0, 0.0, 1.0]])
	T_off_3 = np.array([[-1.0, 0.0, 0.0, 0.0], [0.0, -1.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0], [0.0, 0.0, 0.0, 1.0]])
	T_off_4 = np.array([[0.0, 1.0, 0.0, 0.0], [-1.0, 0.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0], [0.0, 0.0, 0.0, 1.0]])
	lst = [T_off_1, T_off_2, T_off_3, T_off_4]


	for i in range(4):
		T = lst[i]
		print(T)
		iSeeYou, rel, ID, c = detect_tag_camera(img, tag_size, T, cameraParams)
	
	img = cv2.imread('markers.jpg',cv2.IMREAD_GRAYSCALE)

	T_off = np.eye(4)
	detect_aruco_camera(img, tag_size, T_off, cameraParams)
	'''
	T_off = np.eye(4)
	iSeeYou, rel, ID, c = detect_tag_camera_2(img, tag_size, T_off, cameraParams)

main()
"""

'''
[Detection object:
tag_family = b'tag36h11'
tag_id = 60
hamming = 0
decision_margin = 24.732818603515625
homography = [[1.12852846e+01 1.35218628e+01 1.50604021e+02]
 [4.12931891e-01 1.34012105e+01 9.97275963e+01]
 [7.54358942e-03 3.97360209e-02 1.00000000e+00]]
center = [150.60402144  99.72759634]
corners = [[148.07374573 109.20044708]
 [167.49220276 108.4158783 ]
 [153.30262756  89.62454987]
 [132.03965759  90.17698669]]
pose_R = [[ 0.97275506  0.17189059  0.1555674 ]
 [ 0.04820706  0.50638753 -0.86095746]
 [-0.22676788  0.84500017  0.48430469]]
pose_t = [[-0.4970639 ]
 [-0.30799945]
 [ 0.9148219 ]]
pose_err = 1.4234227187580384e-06
, Detection object:
tag_family = b'tag36h11'
tag_id = 82
hamming = 0
decision_margin = 24.04063606262207
homography = [[ 8.02054019e+00  3.10314575e+00  4.66621306e+02]
 [-8.49221724e-01  1.06309763e+01  8.20201682e+01]
 [-3.96118917e-03  1.89261753e-02  1.00000000e+00]]
center = [466.62130564  82.02016819]
corners = [[451.37316895  91.40827179]
 [470.70095825  90.44836426]
 [482.58377075  72.19226074]
 [462.41769409  73.33588409]]
pose_R = [[ 0.96003341 -0.15463188 -0.2332913 ]
 [-0.14024405  0.45556232 -0.87908736]
 [ 0.24221365  0.87667095  0.41566885]]
pose_t = [[ 0.37945231]
 [-0.37270953]
 [ 0.95850859]]
pose_err = 3.8481665025690334e-07
, Detection object:
tag_family = b'tag36h11'
tag_id = 318
hamming = 0
decision_margin = 49.61515808105469
homography = [[-1.18572593e+01  3.08253464e+01  5.37597981e+02]
 [-2.09246950e+01  1.09739259e+01  3.75029839e+02]
 [-1.38257708e-02  3.30089272e-02  1.00000000e+00]]
center = [537.59798111 375.02983943]
corners = [[554.31921387 388.7227478 ]
 [546.09033203 358.20751953]
 [519.23352051 359.99130249]
 [528.7734375  392.51019287]]
pose_R = [[-0.08183852  0.99100632 -0.1058722 ]
 [-0.92256889 -0.03513853  0.38422901]
 [ 0.37705318  0.12911913  0.91714729]]
pose_t = [[0.46192837]
 [0.36769891]
 [0.76352648]]
pose_err = 5.429954298671183e-06
, Detection object:
tag_family = b'tag36h11'
tag_id = 328
hamming = 0
decision_margin = 30.794836044311523
homography = [[ 1.15647124e+01 -1.31398782e+00  3.19180294e+02]
 [ 5.44862875e-01  6.30841077e+00  9.93377081e+01]
 [ 8.41156717e-03 -4.81280377e-03  1.00000000e+00]]
center = [319.18029385  99.33770814]
corners = [[310.40652466 106.50978088]
 [328.24972534 105.81019592]
 [327.72503662  92.35285187]
 [310.04534912  92.81846619]]
pose_R = [[ 9.99085975e-01  4.27458458e-02 -8.01169633e-05]
 [-3.87858311e-02  9.07314404e-01  4.18660042e-01]
 [ 1.79686689e-02 -4.18274269e-01  9.08143030e-01]]
pose_t = [[-0.0521486 ]
 [-0.41622112]
 [ 1.23252283]]
pose_err = 3.0079668027096967e-07
, Detection object:
tag_family = b'tag36h11'
tag_id = 387
hamming = 0
decision_margin = 39.925209045410156
homography = [[-1.31081417e+01  6.81016759e+00  1.79359887e+02]
 [ 3.18874693e-01 -6.31109107e+00  3.22140884e+02]
 [-1.26834699e-03  2.44129945e-02  1.00000000e+00]]
center = [179.35988748 322.14088375]
corners = [[194.28860474 307.61105347]
 [169.14706421 308.99703979]
 [163.6441803  337.43667603]
 [190.05665588 335.90756226]]
pose_R = [[-0.99045956 -0.03036217  0.13441724]
 [ 0.08804465 -0.88980218  0.4477725 ]
 [ 0.10600941  0.45533528  0.88398631]]
pose_t = [[-0.36597334]
 [ 0.26055146]
 [ 0.79989467]]
pose_err = 2.613317301680263e-07
]
'''

