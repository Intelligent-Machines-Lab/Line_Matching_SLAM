#!/usr/bin/env python  

# This code publishes 2 TFs into ROS, odom->base and base->laser
# odom->base needs [x, y, theta] from encoder/imu. For that, it subscribes to 'chatter' and 'yaw'
# base->laser is a static transformation

import roslib
roslib.load_manifest('isis')
import time
import rospy
import tf
from std_msgs.msg import String, Float32
from math import cos, sin
x = 0
y = 0
xyReady = 0
values = [0.0, 0.0]
old_time = 0
def cb(msg):
    global xyReady
    global values
    s = msg.data
    s = s.split(',')
    values = [float(i) for i in s]
    #print(values[0])
    #print(values[1])
    #print(values[2])
    xyReady = 1


def cb2(msg):
    global xyReady
    global values
    global x, y
    global old_time
    yawDeg = msg.data
    yawRad = yawDeg * 0.017453292519944444
    
    #pose.th = wrap180(pose.th);
    # x += (values[0] * cos(yawRad)) * values[1];
    # y += (values[0] * sin(yawRad)) * values[1];
    
    #x += (values[0] * cos(yawRad)) * (time.time() - old_time);
    #y += (values[0] * sin(yawRad)) * (time.time() - old_time);
    #old_time = time.time();
    
    if xyReady:
        br2 = tf.TransformBroadcaster()
        # x, y in meters and theta in radians
        br2.sendTransform((values[0], values[1], 0),
                         tf.transformations.quaternion_from_euler(0, 0, yawRad),
                         rospy.Time.now(),
                         "base_link",
                         "odom")
        xyReady = 0


if __name__ == '__main__':
    rospy.init_node('laser_odom_tf')
    
    br = tf.TransformBroadcaster()
    rate = rospy.Rate(16.0)
    
    rospy.Subscriber("xy", String, cb)
    rospy.Subscriber("yaw", Float32, cb2)
    
    while not rospy.is_shutdown():
        #br.sendTransform((0.0, 0.0, 0.3208), (0, 0, -0.7071, 0.7071), rospy.Time.now(), "laser_frame", "base_link")
        br.sendTransform((0.0, 0.0, 0.3208), (0, 0, 1.0, 0), rospy.Time.now(), "laser_frame", "base_link")
        rate.sleep()
