import serial
import time
import struct

#g = 9.81
#acc = 16.0 / 32768.0 * g
#gyr = 2000 / 32768.0
att = 180 / 32768.0

port = serial.Serial("/dev/ttyAMA0", baudrate=115200, timeout=10.0)

while True:
        start = time.time()
        data = port.read(11)

        #print(data)
        if data[1] == b'\x53':
                axes = struct.unpack("<hhh", data[2:8])
                x3, y3, z3 = [a*att for a in axes]
                #print('Attitude - x:'+str(x3)+', y:'+str(y3)+', z:'+str(z3))
                print(str(z3))
                print(str(time.time() - start))



