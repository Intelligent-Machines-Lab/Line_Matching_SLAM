
"use strict";

let Dock = require('./Dock.js')

module.exports = {
  Dock: Dock,
};
