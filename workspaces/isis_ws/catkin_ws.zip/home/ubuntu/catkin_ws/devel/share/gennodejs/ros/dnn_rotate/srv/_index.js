
"use strict";

let StringTrigger = require('./StringTrigger.js')

module.exports = {
  StringTrigger: StringTrigger,
};
